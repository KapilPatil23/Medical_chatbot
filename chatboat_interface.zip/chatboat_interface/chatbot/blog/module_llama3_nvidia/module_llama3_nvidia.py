from openai import OpenAI

class module_llama3_nvidia:
    def __init__(self):
        self.client = OpenAI(
            base_url="https://integrate.api.nvidia.com/v1",
            api_key="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"
        )

    def create_completion(self, messages):
        return self.client.chat.completions.create(
            model="meta/llama3-70b-instruct",
            messages=messages,
            temperature=0,
            top_p=0.9,
            frequency_penalty=0.1,
            presence_penalty=0.1
        )
