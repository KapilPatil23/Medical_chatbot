import importlib
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from . import models
#from django.db.models
import json
from openai import OpenAI
from chatbot import settings
from django.core.files.storage import FileSystemStorage
import docx
#import xlrd 
import openpyxl
import markdown  # library to get output in proper format 
import bleach
from PyPDF2 import PdfReader
#import ollama
import torch
#from transformers import pipeline
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
#from langchain.memory import ConversationBufferMemory
#from langchain.memory.chat_message_histories import ChatMessageHistory

# Mapping of module names to their respective class paths
MODULES = {
    'llama3_local': 'blog.module_llama3_local.module_llama3_local',
    'llama3_nvidia': 'blog.module_llama3_nvidia.module_llama3_nvidia',
    'gpt_4o': 'blog.module_gpt_4o.module_gpt_4o',
}

#client = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")
#summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
#def summarize_text(text):

    # max_input_length = 1024  # Max input length for BART
    # if len(text) > max_input_length:
    #     text = text[:max_input_length]
   # summary = summarizer(text, max_length=200, min_length=10, do_sample=False)

   # return summary[0]['summary_text']
def index(request):
    if 'chat_history' not in request.session:
         request.session['chat_history']= []

    else:
        request.session['chat_history']= []
           
    
    request.session.save()
    session_id = request.session.session_key
    context = {'session_id': session_id}    

    return render(request, 'blog/index.html', context)
@csrf_exempt
@require_http_methods(["POST"])
def searchPrompt(request):
    botresponse = {}
    if request.method == "POST":
        keyword = request.POST.get("message", "")
        selected_module = request.POST.get("module", "llama3_local")  # default to gpt-4o    
        if keyword:
            # load the conversation memory from session
            chat_id = request.session.session_key
            request.session['chat_history'].append({"role": "user", "content":keyword})

            # request.session['chat_history'].append({"role": "user", "content": keyword}) 
            # dynamically load the selected module class
            if selected_module in MODULES:
                module_path = MODULES[selected_module]
                module_class = importlib.import_module(module_path)
                class_name = module_path.split('.')[-1]
                client_instance = getattr(module_class, class_name)()

                #chat_history = collection.find({'chat_id': chat_id})
                completion = client_instance.create_completion(request.session['chat_history'])

                response_content = completion.choices[0].message.content

                

                # Append assistant response to in-memory chat history
                
                request.session['chat_history'] = [{"role": "assistant", "content": response_content}]
               # request.session['chat_history'].append({"role": "assistant", "content": response_content})

                

                # summarize chat history
                
               # chat_history_text = " ".join([message["content"] for message in request.session['chat_history']])
              #  summarized_chat_history = summarize_text(chat_history_text)
                # Clear the chat history and append the summarized content
               # request.session[''] = [{"role": "user", "content": chat_history}]

            
            # Convert response content to html using markdown
            formatted_response = markdown.markdown(response_content)
            sanitized_response = bleach.clean(formatted_response, tags=['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'ul', 'ol', 'li', 'strong', 'em', 'br', 'hr'], attributes={})
            
            botresponse.update({
                'response': sanitized_response
            })
        
        request.session.save()
    
    return JsonResponse(botresponse)

@require_http_methods(["POST"])
def upload_file(request):
    
    if request.method == 'POST' and request.FILES['uploaded_file']:
        if not 'chat_history' in request.session:
            request.session['chat_history'] = [
                {"role": "system", "content": "You are a helpful assistant."}]
        uploaded_file = request.FILES['uploaded_file']
       
        response = handle_uploaded_file(uploaded_file)
        
        request.session['chat_history'].append({"role":  "user", "content": response})
        request.session.save()
        return JsonResponse({'success': True })
    return JsonResponse({'success': False})

def handle_uploaded_file(uploaded_file):
    
    file_content = ''
    file_extension = uploaded_file.name.split('.')[-1].lower()
    if file_extension == 'docx':
        # Handle docx file
        doc = docx.Document(uploaded_file)
        file_content = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
    elif file_extension == 'xls' or file_extension == 'xlsx':
        # Handle xls/xlsx file
        # Handle xlsx file
        workbook = openpyxl.load_workbook(uploaded_file)
        sheet = workbook.active
        file_content = ''
        for row in sheet.iter_rows(values_only=True):
            file_content += ' '.join([str(cell) for cell in row]) + '\n'
    elif file_extension == 'pdf':
        # Handle pdf file
        pdf_reader = PdfReader(uploaded_file)
        file_content = ''
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            file_content += page.extract_text()
    else:
        for chunk in uploaded_file.chunks():
            file_content += chunk.decode('utf-8')  
        # Unsupported file type
    return file_content

# import importlib
# from django.shortcuts import render
# from django.http import HttpResponse, JsonResponse
# from . import models
# #from django.db.models
# import json
# from openai import OpenAI
# from chatbot import settings
# from django.core.files.storage import FileSystemStorage
# import docx
# #import xlrd 
# import openpyxl
# import markdown  # library to get output in proper format 
# import bleach
# from PyPDF2 import PdfReader
# #import ollama
# from transformers import pipeline
# from blog.chromadb_setup import upsert_chat_summaries, query_chat_summaries # ensure this import the chromadb
# from django.http import JsonResponse
# from django.views.decorators.http import require_http_methods
# from django.views.decorators.csrf import csrf_exempt
# # # Initialize the OpenAI client pointing to the local Llama 3 server

# # mappig of mudule names to their respective class paths
# MODULES = {
#     'llama3_local': 'blog.module_llama3_local.module_llama3_local',
#     'llama3_nvidia': 'blog.module_llama3_nvidia.module_llama3_nvidia',
#     'gpt_4o': 'blog.module_gpt_4o.module_gpt_4o',

# }
# #client = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")

# summarizer = pipeline("summarization")

# def summarize_text(text):
#     summary = summarizer(text, max_length= 100, min_length = 30, do_sample =False)
#     return summary[0]['summary_text']


# def index(request):
#     if 'chat_history' not in request.session:
#         request.session['chat_history']= []

#     else:
#         request.session['chat_history']= []
           
    
#     request.session.save()
#     session_id = request.session.session_key
#     context = {'session_id': session_id}    

#     return render(request, 'blog/index.html', context)

# @csrf_exempt
# @require_http_methods(["POST"])
# def searchPrompt(request):
#     botresponse = {}
#     if request.method == "POST":
#         keyword = request.POST.get("message", "")
#         selected_module = request.POST.get("module", "llama3_local")  # default to gpt-4o    
        
#         if keyword:
            
#             #request.session['chat_history'].append({"role": "user", "content": keyword})
#             chat_id = request.session.session_key

#             # Append to in-memory chat history
#             request.session['chat_history'].append({"role": "user", "content": keyword})

#             # Store user message in ChromaDB
#            # user_kay_point = generate_key_points(keyword)
        
#             # dynamically load the selected module class
#             if selected_module in MODULES:
#                 module_path = MODULES[selected_module]
#                 module_class = importlib.import_module(module_path)
#                 class_name = module_path.split('.')[-1]
#                 client_instance = getattr(module_class, class_name)()
#                 #module = importlib.import_module('blog.module_llama3_local.module_llama3_local')
#                 #client_instance = getattr(module, 'Llama3LocalClient')()


#                 # completion = client_instance.create_completion(request.session['chat_history'])

#                 # response_content = completion.choices[0].message.content
#                 # request.session['chat_history'].append({"role": "assistant", "content": response_content})
#                   # Retrieve the chat history from ChromaDB
#                 #chat_history = query_chat_key_points(chat_id)
#                  # Summarize the chat history
#                 chat_history_text = " ".join([f"{entry['role']}: {entry['content']}" for entry in request.session['chat_history']])
#                 chat_summary = summarize_text(chat_history_text)

#                 # Retrieve previous summaries from ChromaDB
#                 previous_summaries = query_chat_summaries(chat_id)
#                 # In views.py
#                 if isinstance(previous_summaries, list):
#                     previous_summaries_text = " ".join(previous_summaries)
#                 else:
#                     previous_summaries_text = ""


#                 # Combine previous summaries with the new chat summary
#                 prompt = f"{previous_summaries_text} {chat_summary}"
#                 completion = client_instance.create_completion(prompt)

#                 response_content = completion.choices[0].message.content

#                 # Append assistant response to in-memory chat history
#                 request.session['chat_history'].append({"role": "assistant", "content": response_content})

#                 # Summarize the assistant response
#                 response_summary = summarize_text(response_content)

#                 # Upsert summaries to ChromaDB
#                 summaries = [chat_summary, response_summary]
#                 upsert_chat_summaries(chat_id, summaries)
#                 formatted_response = markdown.markdown(response_content)
#                 sanitized_response = bleach.clean(formatted_response, tags=['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'ul', 'ol', 'li', 'strong', 'em', 'br', 'hr'], attributes={})
            
#                 botresponse.update({'response': sanitized_response})
        
#         request.session.save()
    
#     return JsonResponse(botresponse)


# @csrf_exempt  
# @require_http_methods(["POST"])
# def upload_file(request):
    
#     if request.method == 'POST' and request.FILES['uploaded_file']:
#         if not 'chat_history' in request.session:
#             request.session['chat_history'] = [
#                 {"role": "system", "content": "You are a helpful assistant."}]
#         uploaded_file = request.FILES['uploaded_file']
#         # fs = FileSystemStorage()
#         # filename = fs.save(uploaded_file.name, uploaded_file)
#         # file_path = fs.path(filename)
#         # file_completion = client.files.create(
#         #     file=open(file_path, 'rb'),
#         #     purpose='fine-tune'
#         # )
#         response = handle_uploaded_file(uploaded_file)
        
#         request.session['chat_history'].append({"role":  "user", "content": response})
#         request.session.save()
#         return JsonResponse({'success': True })
#     return JsonResponse({'success': False})

# def handle_uploaded_file(uploaded_file):
    
#     file_content = ''
#     file_extension = uploaded_file.name.split('.')[-1].lower()

#     if file_extension == 'docx':
#         # Handle docx file
#         doc = docx.Document(uploaded_file)
#         file_content = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
#     elif file_extension == 'xls' or file_extension == 'xlsx':
#         # Handle xls/xlsx file

#         # Handle xlsx file
#         workbook = openpyxl.load_workbook(uploaded_file)
#         sheet = workbook.active
#         file_content = ''
#         for row in sheet.iter_rows(values_only=True):
#             file_content += ' '.join([str(cell) for cell in row]) + '\n'
#     elif file_extension == 'pdf':
#         # Handle pdf file
#         pdf_reader = PdfReader(uploaded_file)
#         file_content = ''
#         for page_num in range(len(pdf_reader.pages)):
#             page = pdf_reader.pages[page_num]
#             file_content += page.extract_text()
#     else:
#         for chunk in uploaded_file.chunks():
#             file_content += chunk.decode('utf-8')  
#         # Unsupported file type
#     return file_content

