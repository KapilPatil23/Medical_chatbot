from chromadb import ChromaClient

# Initialize the ChromaDB client
client = ChromaClient()

# Define your collection schema
collection_schema = {
    'chat_id': 'string',
    'role': 'string',
    'content': 'string'
}

# Create or get a collection
collection_name = 'chat_history'
if not client.collection_exists(collection_name):
    collection = client.create_collection(collection_name, schema=collection_schema)
else:
    collection = client.get_collection(collection_name)
