from openai import OpenAI
from chatbot import settings

class module_gpt_4o:
    def __init__(self):
        self.client = OpenAI(api_key=settings.API_KEY)

    def create_completion(self, messages):
        return self.client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            temperature=0,
            top_p=0.9,
            frequency_penalty=0.1,
            presence_penalty=0.1
        )
    #print(f'{response.usage.prompt_tokens} prompt tokens used.')