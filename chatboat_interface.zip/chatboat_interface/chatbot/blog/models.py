from django.db import models
from django.utils import timezone
import django
from django.utils.translation import gettext_lazy as _

class ChatResponse(models.Model):
    id = models.BigAutoField(primary_key=True)
    userMessage = models.CharField(max_length=256)
    botResponse = models.CharField(max_length=256)
    
    
class PatientDetails(models.Model):
    id = models.BigAutoField(primary_key=True)
    reg_number = models.CharField(max_length=256)
    patient_name = models.CharField(max_length=256)
    blood_group = models.CharField(max_length= 256, null = True, blank = True)
    phone_number = models.CharField(max_length= 256, null = True, blank = True)
        
class Visits(models.Model):
    id = models.BigAutoField(primary_key = True)
    patient = models.ForeignKey(PatientDetails, models.RESTRICT,
                                blank=True, null=True, related_name='patient_info')   
    date = models.DateTimeField(auto_now = True)
    

# class Vitals(models.Model):
#     id = models.BigAutoField(primary_key = True)
#     name = models.CharField(max_length= 256, null = True, blank = True)

class VitalsName(models.IntegerChoices):
    BloodPreesure = 3, _('Blood Pressure')
    Weight = 1,('Weight')
    BloodOxygen = 4,('Blood Oxygen Level')
    PulseRate = 2,('Pulse Rate')
          
class Reports(models.Model)  :
    id = models.BigAutoField(primary_key = True )
    visit = models.ForeignKey(Visits, models.RESTRICT,
                                blank=True, null=True, related_name='visit_info')  
    vital = models.PositiveSmallIntegerField(
        choices=VitalsName.choices)
    value = models.CharField(max_length = 256)
        
        
# Create your models here.
