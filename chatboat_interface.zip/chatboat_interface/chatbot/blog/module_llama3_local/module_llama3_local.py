from openai import OpenAI

class module_llama3_local:
    def __init__(self):
        self.client = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")

    def create_completion(self, messages):
        return self.client.chat.completions.create(
            model="llama3",
            messages=messages,
            temperature=0.7,
            top_p=0.9,
            frequency_penalty=0.1,
            presence_penalty=0.1
        )
