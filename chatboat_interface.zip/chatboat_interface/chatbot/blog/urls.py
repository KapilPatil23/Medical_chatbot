# from django.urls import path
# from . import views
# app_name = 'blog'


# urlpatterns = [
   
#     # path('p_details',views.getPatientDetails, name = 'p_details'),
#     # path('p_name',views.getPatientName, name = 'p_name'),
#     # path('blood_group',views.getBloodGroup, name = 'blood_group'),
#     # path('getResponse',views.getResponse, name = 'getResponses'),
#     path('', views.index, name = 'index' ),
#     path('message', views.searchPrompt, name = 'prompt' ),
#     path('upload_file', views.upload_file, name='upload_file'),
    
#     # path('specific', views.specific, name = 'specific' ),
#     # path('article/<int:pk>', views.article , name = 'article')
# ]
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('searchPrompt/', views.searchPrompt, name='searchPrompt'),
    path('upload_file/', views.upload_file, name='upload_file'),
]
